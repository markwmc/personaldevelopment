var usersService = {
  endpoint: "https://api.remotebootcamp.dev/api/users",
};

usersService.userLogin = (payload) => {
  const config = {
    method: "POST",
    url: usersService.endpoint + "/login",
    data: payload,
    crossdomain: true,
    headers: { "Content-Type": "application/json" },
  };

  return axios(config);
};
